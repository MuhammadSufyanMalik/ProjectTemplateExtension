﻿namespace $safeprojectname$.Concrete
{
    public class User
    {

    }
}